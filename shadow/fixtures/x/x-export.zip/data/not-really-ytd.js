// not a YTD file
console.log("just a script, not window.YTD-wrapped");
